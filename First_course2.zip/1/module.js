// File	name: Module.js
// Created: 01.12.2005
// Copyright (c) Websoft, 2006.	All rights reserved.


// InitModule
function InitModule()
{
}

// ShutdownModule
function ShutdownModule()
{
}
